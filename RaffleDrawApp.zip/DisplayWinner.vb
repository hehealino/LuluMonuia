﻿'This form should display all winners in the raffle
Imports System.IO

Public Class DisplayWinner
    Dim Msg, Style, Title, Response, MyString 'To display warning message when closing window
    Dim count As Integer

    Public Sub List_column()
        With WinnersList
            .View = View.Details
            .FullRowSelect = True
            .GridLines = True
            'create columns in listview
            .Columns.Add("Pale:", 800)
            .Columns.Add("Fika Tikite", 200)
            .Columns.Add("Hingoa", 500)
            .Columns.Add("Feitu'u", 420)
            .Columns.Add("Fika Telefoni", 320)

        End With
        Call SaveWinnersToFile()
    End Sub

    Private Sub DisplayWinner_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call List_column()

    End Sub

    Private Sub DisplayWinner_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Msg = "You will lose all stored winners. Are you sure you want to close this window?"
        Style = vbOKCancel Or vbCritical Or vbQuestion
        Title = "WARNING!"
        Response = MsgBox(Msg, Style, Title)
        If Response = vbCancel Then
            e.Cancel = True

        End If
    End Sub

    ' In the DisplayWinner form, when saving the winner list
    Private Sub SaveWinnersToFile()
        Dim sw As New StreamWriter("D:\winners.txt", True)
        For Each item As ListViewItem In WinnersList.Items
            sw.WriteLine(item.Text & "," & item.SubItems(1).Text & "," & item.SubItems(2).Text & "," & item.SubItems(3).Text & "," & item.SubItems(4).Text)
        Next
        sw.Close()
    End Sub
End Class